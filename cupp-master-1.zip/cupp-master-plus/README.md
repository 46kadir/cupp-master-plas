# CUPP - Ortak Kullanıcı Şifreleri Profilcisi

[![Derleme Durumu](https://travis-ci.org/Mebus/cupp.svg?branch=master)](https://travis-ci.org/Mebus/cupp)
[![Kapsam Durumu](https://coveralls.io/repos/github/Mebus/cupp/badge.svg)](https://coveralls.io/github/Mebus/cupp)
[![Codacy Rozeti](https://api.codacy.com/project/badge/Grade/a578dde078ef481e97a0e7eac0c8d312)](https://app.codacy.com/app/Mebus/cupp?utm_source=github.com&utm_medium=referral&utm_content =Mebus/cupp&utm_campaign=Badge_Grade_Dashboard)
[![Rawsec'in Siber Güvenlik Envanteri](https://inventory.raw.pm/img/badges/Rawsec-inventoried-FF5050_plastic.svg)](https://inventory.raw.pm/)

 
## Hakkında

   En yaygın kimlik doğrulama biçimi, bir kullanıcı adının birleşimidir.
   ve bir şifre veya parola. Her ikisi de yerel olarak depolanan değerlerle eşleşirse
   saklanan tablo, kullanıcının bir bağlantı için kimliği doğrulanır. Şifre gücü
   şifreyi tahmin etme veya kırma ile ilgili zorluğun bir ölçüsü
   kriptografik teknikler veya kitaplık tabanlı otomatik test yoluyla
   alternatif değerler.

   Zayıf bir parola çok kısa olabilir veya yalnızca alfasayısal karakterler kullanabilir,
   şifre çözmeyi basitleştirme. Zayıf bir parola, kolayca
   doğum günü, takma ad, adres gibi kullanıcının profilini çıkaran biri tarafından tahmin edilen,
   bir evcil hayvanın veya akrabanın adı veya Tanrı, aşk, para veya şifre gibi yaygın bir kelime.

   CUPP bu yüzden doğdu ve yasal gibi durumlarda kullanılabilir.
   sızma testleri veya adli suç soruşturmaları.


Gereksinimler
------------

CUPP'yi çalıştırmak için Python 3'e ihtiyacınız var.

Hızlı başlangıç
-----------

     $ python3 cupp.py -h

## Seçenekler

   Kullanım: cupp.py [SEÇENEKLER]

         -h bu menü

         -i Kullanıcı şifresi profili oluşturma için etkileşimli sorular

         -w Mevcut sözlüğü profillemek için bu seçeneği kullanın,
                 veya biraz pwnsauce yapmak için WyD.pl çıktısı :)

         -l Depodan büyük kelime listeleri indirin

         -a Varsayılan kullanıcı adlarını ve parolaları doğrudan Alecto DB'den ayrıştırın.
                 Project Alecto, Phenoelit ve CIRT'in birleştirilmiş ve geliştirilmiş saflaştırılmış veritabanlarını kullanır.

         -v Programın sürümü



## Yapılandırma

    CUPP, yönergeleri içeren cupp.cfg yapılandırma dosyasına sahiptir.

## Örnek (Hızlı ileri)

![kupp örneği](ekran görüntüleri/kupp örneği.gif)

## Lisans

   Bu program ücretsiz bir yazılımdır; yeniden dağıtabilir ve/veya değiştirebilirsiniz
   tarafından yayınlanan şekliyle GNU Genel Kamu Lisansı koşulları altında
   Özgür Yazılım Vakfı; Lisansın 3. versiyonu veya
   sonraki herhangi bir sürüm.

   Bu program faydalı olması ümidiyle dağıtılmaktadır,
   ancak HİÇBİR GARANTİ OLMAKSIZIN; zımni garantisi bile olmadan
   SATILABİLİRLİK veya BELİRLİ BİR AMACA UYGUNLUK. Bkz.
   Daha fazla ayrıntı için GNU Genel Kamu Lisansı.

   GNU Genel Kamu Lisansının bir kopyasını almış olmalısınız
   bu programla birlikte; değilse, Özgür Yazılım'a yazın
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 ABD

   Daha fazla bilgi için './LICENSE' bölümüne bakın.

## Github içe aktarma

Bu proje Mebus tarafından https://github.com/Mebus/cupp'a şu adresten aktarılmıştır:
http://www.remote-exploit.org/content/cupp-3.0.tar.gz
http://www.remote-exploit.org/articles/misc_research__amp_code/index.html
aracın daha da geliştirilmesini teşvik etmek.

## Original yapımcı

  Muris Kurgas aka j0rgan  
  j0rgan@remote-exploit.org  
  http://www.remote-exploit.org  
  http://www.azuzi.me  


## katkıda bulunanlar
  *Çeviri yapan ve geliştiren by Kadir Yılmaz
  
  * Bosko Petrovic namı diğer bolexxx
  bole_loser@hotmail.com  
  http://www.offensive-security.com  
  http://www.bolexxx.net  

  * Mebus  
    https://github.com/Mebus/  

  * Abhro  
    https://github.com/Abhro/  

  * Andrea Giacomo  
    https://github.com/codepr

  * quantumcore  
    https://github.com/quantumcore
    

