#CUPP değişiklik günlüğü

Bu projedeki tüm önemli değişiklikler bu dosyada belgelenecektir.
Bu proje [Semantik Versiyon Oluşturma](http://semver.org/) ile uyumludur.

## 3.2.0-alfa

  - Python3 uyumlu hale getirmek için cupp.py'de 2to3 çalıştırdı

## 3.1.0-alfa
  - Python3 bağlantı noktası eklendi
  - Hata düzeltmeleri

## 3.0.0
  - kelime uzunluğu şekillendirme işlevi eklendi
  - kelime listeleri indirici işlevi eklendi
  - alectodb ayrıştırıcı eklendi
  - sözcük birleştirmeleri için sabit eşikler
  - son ayrıştırmada sabit sıralama
  - bazı kullanıcı girişi doğrulamaları düzeltildi
  - ascii inek şimdi daha güzel görünüyor :)

## 2.0.0
  - l33t modu eklendi
  - karakter modu eklendi
  - diğer kelime listeleri veya wyd.pl çıktıları ile pwnsauce yapma yeteneği
  - cupp.cfg, cupp.py'nin yapılandırılmasını kolaylaştırır


## 1.0.0
- İlk sürüm